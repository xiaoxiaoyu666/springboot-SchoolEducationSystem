package com.xy.sky.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SystemConfig {

	// 设置客户端的字符编码（淘汰）
//	@Bean
//	public FilterRegistrationBean characterEncodingFilter() {
//		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
//		
//		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
//		
//		characterEncodingFilter.setEncoding("utf-8");
//		
//		filterRegistrationBean.setFilter(characterEncodingFilter);
//		
//		filterRegistrationBean.addUrlPatterns("/*");
//		
//		return filterRegistrationBean;
//	}

	// 添加转化器
//	@Bean
//	public ConversionServiceFactoryBean conversionService() {
//		ConversionServiceFactoryBean conversionServiceFactoryBean = new ConversionServiceFactoryBean();
//		Set<Object> arr = new HashSet<Object>();
//		arr.add(new DateConverter());
//		conversionServiceFactoryBean.setConverters(arr);
//
//		return conversionServiceFactoryBean;
//	}

	// 配置异常处理器
//	@Bean
//	public SimpleMappingExceptionResolver ExceptionResolver() {
//		SimpleMappingExceptionResolver simpleMappingExceptionResolver = new SimpleMappingExceptionResolver();
//		simpleMappingExceptionResolver.setDefaultErrorView("defaultError.html");
//
//		Properties map = new Properties();
//		map.put("java.sql.SQLException", "daoError.html");
//		simpleMappingExceptionResolver.setExceptionMappings(map);
//
//		return simpleMappingExceptionResolver;
//	}
}
