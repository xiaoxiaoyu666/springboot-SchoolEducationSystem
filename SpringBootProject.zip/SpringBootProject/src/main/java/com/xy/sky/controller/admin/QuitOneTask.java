package com.xy.sky.controller.admin;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("admin")
public class QuitOneTask {
	@RequestMapping("quitOneTask")
	public String quitOneTask() {

		return "admin/allStudentTasks.html";
	}

}
