package com.xy.sky.controller.do_show;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.controller.CheckLogin;
import com.xy.sky.controller.CheckVerify;
import com.xy.sky.service.StudentServiceInter;

@Controller

public class DoLogin {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "DoLogin", method = RequestMethod.POST)
	public String doLogin(String id, String password, String select, String rember, String code, Model model,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
		/*
		 * 需要用户输入的类型全部为String：因为用户可能会输入其他格式 首先进行数据绑定：以便用户输入有误的时候可以记住用户之前输入的内容 判断用户输入是否为空
		 * 捕捉用户输入格式错误
		 */

		CheckLogin cl = new CheckLogin();
		CheckVerify cv = new CheckVerify();

		ResultCode resultcl = cl.checkLogin(id, password, select, code, studentService);
		ResultCode resultcv = cv.checkVerify(code, session);

		if (resultcl.getCode() == Common.SUCCESS && resultcv.getCode() == Common.SUCCESS) {
			session.setAttribute("userId", id);
			session.setAttribute("select", select);

			session.setAttribute("user", new User(Integer.parseInt(id), password, select));

			session.setAttribute("text", studentService.GetAdminName(new User(Integer.parseInt(id), password, select)));

			return "admin/loginSuccess.html";

		} else {
			String error;
			if (resultcl.getCode() != Common.SUCCESS) {
				error = resultcl.getMsg();
			} else {
				error = resultcv.getMsg();
				model.addAttribute("password", password);
			}
			model.addAttribute("error", error);

			return "login.html";

		}

	}
}
