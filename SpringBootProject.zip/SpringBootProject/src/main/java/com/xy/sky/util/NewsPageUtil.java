package com.xy.sky.util;

import javax.servlet.http.HttpSession;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.News;
import com.xy.sky.bean.User;
import com.xy.sky.service.NewsServiceInter;

public class NewsPageUtil implements PageHelperUtil<News> {

	private NewsServiceInter newsService;
	private HttpSession session;
	private String order;

	public NewsPageUtil(NewsServiceInter newsService, HttpSession session, String order) {
		super();
		this.newsService = newsService;
		this.session = session;
		this.order = order;
	}

	@Override
	public PageInfo<News> realPageInfo(String thePage) {
		Integer currentPage = getCurrentPage(thePage);
		PageInfo<News> pageInfoDemo;

		if (session.getAttribute("toCollect") != null && ((String) session.getAttribute("toCollect")).equals("true"))
			pageInfoDemo = newsService.getCollectedNews((User) session.getAttribute("user"), currentPage, order);
		else
			pageInfoDemo = newsService.queryNews(currentPage, order);
		// 判断当前页是否溢出
		if (currentPage < 1)
			currentPage = 1;
		else if (currentPage > pageInfoDemo.getPages())
			currentPage = pageInfoDemo.getPages();

		PageInfo<News> pageInfo;
		if (session.getAttribute("toCollect") != null && ((String) session.getAttribute("toCollect")).equals("true"))
			pageInfo = newsService.getCollectedNews((User) session.getAttribute("user"), currentPage, order);
		else
			pageInfo = newsService.queryNews(currentPage, order);

		return pageInfo;
	}

	@Override
	public Integer getCurrentPage(String thePage) {
		Integer currentPage = 1;
		if (thePage != null)
			currentPage = Integer.parseInt((String) thePage);

		return currentPage;
	}

}
