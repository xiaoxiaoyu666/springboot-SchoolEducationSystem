package com.xy.sky.service.impl;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.xy.sky.bean.Course;
import com.xy.sky.bean.Curriculum;
import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Student;
import com.xy.sky.bean.Task;
import com.xy.sky.bean.TaskScore;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.mapper.ClassMapper;
import com.xy.sky.mapper.CourseMapper;
import com.xy.sky.mapper.StudentJoinClassMapper;
import com.xy.sky.mapper.StudentMapper;
import com.xy.sky.mapper.TaskMapper;
import com.xy.sky.mapper.TaskScoreMapper;
import com.xy.sky.mapper.TeacherMapper;
import com.xy.sky.mapper.UserMapper;
import com.xy.sky.service.StudentServiceInter;

@Service("studentSerivce")
@Transactional
@Scope("prototype")
public class StudentService implements StudentServiceInter {
	@Autowired
	private StudentMapper studentMapper;
	@Autowired
	private UserMapper userMapper;
	@Autowired
	private StudentJoinClassMapper studentJoinClassMapper;
	@Autowired
	private ClassMapper classMapper;
	@Autowired
	private CourseMapper courseMapper;
	@Autowired
	private TeacherMapper teacherMapper;
	@Autowired
	private TaskMapper taskMapper;
	@Autowired
	private TaskScoreMapper taskScoreMapper;

	@Autowired
	private DataSource dataSourse;

//	public Student queryStudentById(Integer id) {
//		return studentMapper.selectByPrimaryKey(id);
//	}
	// 注册时判断重复的用户名
	public int judgeRepeatAdmin(Integer id, String select) {
		List<Integer> rs = userMapper.getAdminIds(select);

		int temp = 0;

		if (rs.contains(id)) {

			temp = 1;
		}

		return temp;
	}

	// 分页查询学生信息
	public PageInfo<Student> queryByPageForStudentJoinClass(Integer currentPage) {
		Integer pageRecords = 3;

		PageHelper.startPage(currentPage, pageRecords);

		List<Student> st = studentJoinClassMapper.getStudentJoinClass();

		PageInfo<Student> pageInfo = new PageInfo<Student>(st);

		return pageInfo;
	}

	// 修改密码
	public boolean upPassword(String id, String p1, String p2, String select) {
		if (!p1.equals(p2)) {
			return false;

		} else {
			User user = new User(Integer.parseInt(id), p2, select);
			userMapper.upDatePsw(user);

			return true;
		}
	}

	// 修改学生信息
	public void DoUpDateStudentInfo(Student st) {
		studentMapper.updateByPrimaryKey(st);
	}

	// 获取课程名
	public String GetClassName(Integer classId) {
		String className = classMapper.getClassName(classId);
		return className;
	}

	// 判断用户名密码是否正确
	public boolean JudgeAdminAndPsw(Integer id, String password, String select) {
		if (userMapper.getAdminIds(select).contains(id)
				&& userMapper.getPsword(new User(id, password, select)).equals(password)) {
			return true;
		} else {
			return false;
		}
	}

	// 获取用户名
	public String GetAdminName(User user) {
		return userMapper.getAdminName(user);
	}

	// 获取学生信息
	public PageInfo<Student> queryOnesStudentInfo(Integer id, String name, Integer classid, Integer currentPage) {

		PageHelper.startPage(currentPage, 3);

		List<Student> students = studentJoinClassMapper.queryOnesStudentInfo(id, name, classid);

		PageInfo<Student> pageInfo = new PageInfo<>(students);

		return pageInfo;
	}

	// 删除学生信息
	public void deleteByPrimaryKey(Integer id) {
		studentMapper.deleteByPrimaryKey(id);
	}

	// 添加用户
	public void addInfo(User user, String name) {
		userMapper.addInfo(user, name);
	}

	// 课程分页信息
	public PageInfo<Course> chooseCourse(Integer currentPage) {
		PageHelper.startPage(currentPage, 5);

		List<Course> courses = courseMapper.courseJoinTeacher();

		PageInfo<Course> CoursePageInfo = new PageInfo<>(courses);

		return CoursePageInfo;
	}

	// 更新课程人数
	public void addStudentToCourse(Integer courseId, Integer studentId) {

		courseMapper.addCourseOfStudent(courseId, studentId);

	}

	// 获取已选择的课程
	public List<Integer> getChoosedCourse(Integer studentId) {
		List<Integer> choosedCourses = courseMapper.getChoosedCourse(studentId);
		return choosedCourses;
	}

	// 更新课表
	public void updateCurriculum(String courseTimeColumn, Integer courseId, Integer studentId) {
		List<Integer> studentIds = courseMapper.querryStudentIdInCurriculum();

		if (studentIds.contains(studentId)) {
			courseMapper.addCourseAtTime(courseTimeColumn, courseId, studentId);

		} else {
			courseMapper.addCurriculum(courseTimeColumn, courseId, studentId);
		}

	}

	// 判断时段内是否已有课程
	public ResultCode JudgeCourseInCurriculum(String courseTimeColumn, Integer studentId) {
		List<Integer> studentIds = courseMapper.querryStudentIdInCurriculum();
		ResultCode rc = new ResultCode(100, "");
		if (studentIds.contains(studentId)) {
			String course = courseMapper.querryCourseAtTime(courseTimeColumn, studentId);
			if (course != null) {
				rc.setCode(Common.CLIENTFAILED);
				rc.setMsg("该时段你已有课程");
			}
		}
		return rc;
	}

	// 判断是否有课表
	public ResultCode JudgeHaveCurriculum(Integer studentId) {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		List<Integer> StudentIdInCurriculum = courseMapper.querryStudentIdInCurriculum();
		if (!StudentIdInCurriculum.contains(studentId)) {
			rc.setCode(Common.CLIENTFAILED);
			rc.setMsg("没有课程，快去选课");
		}
		return rc;
	}

	public List<Curriculum> getCurriculum(Integer studentId) {
		List<Integer> list = new ArrayList<>();
		try {
			Connection conn = dataSourse.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from s_curriculum where student_id=" + studentId);
			while (rs.next()) {
				for (int i = 2; i <= 21; i++) {
					list.add(rs.getInt(i));
				}
			}
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<String> list1 = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) != 0) {
				list1.add(courseMapper.getCourseNameById(list.get(i)));
			} else {
				list1.add(null);
			}
		}

		List<String> arrcourse1 = new ArrayList<String>();
		List<String> arrcourse2 = new ArrayList<String>();
		List<String> arrcourse3 = new ArrayList<String>();
		List<String> arrcourse4 = new ArrayList<String>();

		for (int i = 0; i < list1.size(); i = i + 4) {
			arrcourse1.add(list1.get(i));
		}
		for (int i = 1; i < list1.size(); i = i + 4) {
			arrcourse2.add(list1.get(i));
		}
		for (int i = 2; i < list1.size(); i = i + 4) {
			arrcourse3.add(list1.get(i));
		}
		for (int i = 3; i < list1.size(); i = i + 4) {
			arrcourse4.add(list1.get(i));
		}

		Curriculum course1 = new Curriculum(arrcourse1);
		Curriculum course2 = new Curriculum(arrcourse2);
		Curriculum course3 = new Curriculum(arrcourse3);
		Curriculum course4 = new Curriculum(arrcourse4);

		List<Curriculum> result = new ArrayList<>();
		result.add(course1);
		result.add(course2);
		result.add(course3);
		result.add(course4);

		return result;
	}

	public List<String> getAllTeachersName() {
		List<String> TeachersNames = teacherMapper.getAllTeachersName();
		return TeachersNames;
	}

	public Set<String> getAllCoursesName() {
		Set<String> allCoursesName = courseMapper.getAllCoursesName();
		return allCoursesName;
	}

	public ResultCode UpLoadTask(String teacherName, String courseName, Integer studentId, String taskName, String url,
			MultipartFile upLoadFile) throws Exception {
		ResultCode rc = new ResultCode(Common.SUCCESS, "上传成功");

		List<Integer> teacherIds = courseMapper.getTeacherIdsByName(teacherName);
		Integer theTeacherId = null;
		Integer theCourseId = null;
		// 判断哪个老师是学生所选的课程的老师
		loop: for (Integer teacherId : teacherIds) {
			List<Integer> courseIds = courseMapper.getCourseIdByTeacherAndCourse(courseName, teacherId);
			for (Integer courseId : courseIds) {
				List<Integer> studentIds = courseMapper.getStudentIdByCourseId(courseId);
				if (studentIds.contains(studentId)) {
					theTeacherId = teacherId;
					theCourseId = courseId;
					break loop;
				}
			}

		}
		String fileName = upLoadFile.getOriginalFilename();
//		String fileName = null;
//		InputStream fileInputStream = null;
//		Set<Entry<String, InputStream>> entrySet = fileMap.entrySet();
//		for (Entry<String, InputStream> entry : entrySet) {
//			fileName = entry.getKey();
//			fileInputStream = entry.getValue();
//		}

		boolean isContainTask = false;
		List<TaskScore> tasks = taskScoreMapper.getTaskScoreByStudentId(studentId);
		for (TaskScore task : tasks) {
			if (task.getTaskName().equals(taskName + fileName)) {
				isContainTask = true;
				break;
			}

		}

		if (theTeacherId == null) {
			rc.setCode(Common.CLIENTFAILED);
			rc.setMsg("所选课程和老师无法匹配");
			return rc;
		} else if (isContainTask == true) {
			rc.setCode(Common.CLIENTFAILED);
			rc.setMsg("您已提交此作业，并已修改，请联系老师");
			return rc;
		} else {
			// 数据库添加信息
			taskMapper.addTask(new Task(studentId, theCourseId, taskName + fileName, url));

			// 文件上传
//			try {
//				upLoadFile.transferTo(new File(url + taskName + fileName));
//			} catch (IllegalStateException e) {
//				e.printStackTrace();
//				rc.setCode(Common.SERVERFAILED);
//				rc.setMsg("文件上传错误");
//				return rc;
//			} catch (IOException e) {
//				e.printStackTrace();
//				rc.setCode(Common.CLIENTFAILED);
//				rc.setMsg("文件格式错误");
//				return rc;
//			}

			// 远程上传文件
			Client client = Client.create();

			WebResource resource = client.resource(url + URLEncoder.encode(taskName + fileName, "utf-8"));
			resource.setProperty("User-Agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36");
			resource.put(upLoadFile.getBytes());

//			try {
//				String boundary = "----WebKitFormBoundaryAsaaHpUFlIN97Nr5";
//				DataInputStream inputStream = new DataInputStream(upLoadFile.getInputStream());
//				DataInputStream inputStream = new DataInputStream(fileInputStream);
//				byte[] bytes = upLoadFile.getBytes();
//				String name = upLoadFile.getName();
//				String contentType = upLoadFile.getContentType();
//				URL urls = new URL("http", "127.0.0.1", 8081, "/Desktop/taskFile/");
//				HttpURLConnection openConnection = (HttpURLConnection) urls.openConnection();
//
//				openConnection.setRequestMethod("POST");
//				openConnection.setRequestProperty("Connection", "Keep-Alive");
//				openConnection.setRequestProperty("User-Agent",
//						"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36");
//				openConnection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
//				openConnection.setDoInput(true);
//				openConnection.setDoOutput(true);
//				openConnection.connect();
//				OutputStream outputStream = openConnection.getOutputStream();
//				OutputStream dout = new DataOutputStream(outputStream);
//				StringBuffer s = new StringBuffer();
//				s.append("--" + boundary + "\r\n");
//				s.append("Content-Disposition: form-data; name=\"" + name + "\"; filename=\"" + fileName + "\"\r\n");
//				s.append("Content-Type: " + contentType + "\r\n\r\n");
//				dout.write(s.toString().getBytes());
//				byte[] b = new byte[102400];
//				int read = inputStream.read(b);
//				System.out.println(new String(b, 0, read) + "\r\n" + s);
//				dout.write(b, 0, read);
//				dout.write(bytes);
//				dout.write(("\r\n--" + boundary + "--\r\n").getBytes());

//				dout.flush();
//			} catch (MalformedURLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
		}

		return rc;

	}

	public List<Task> queryOneStudentTask(Integer studentId) {
		List<Task> tasks = taskMapper.querryTaskByStudentId(studentId);
		for (Task task : tasks) {
			String courseName = courseMapper.getCourseNameById(task.getCourseId());
			Course course = new Course();
			course.setName(courseName);
			task.setCourse(course);
		}
		return tasks;
	}

	public ResultCode deleteTask(Integer courseId, Integer studentId, String fileUrl, String taskName)
			throws Exception {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");

		// 删除本地文件
//		File delFile = new File(fileUrl + taskName);
//		if (delFile.isFile() && delFile.exists()) {
//			delFile.delete();
//		} else {
//			rc.setCode(Common.SERVERFAILED);
//			rc.setMsg("没有该文件删除失败");
//			System.out.println(rc.getMsg() + " " + fileUrl);
//		}

		// 删除远程服务器上的文件
		URL url = new URL(fileUrl + taskName);
		HttpURLConnection openConnection = (HttpURLConnection) url.openConnection();
		int responseCode = openConnection.getResponseCode();
		if (responseCode > 300) {
			rc.setCode(Common.SERVERFAILED);
			rc.setMsg("删除失败");
			return rc;
		}
		// 数据库删除作业数据
		taskMapper.deleteTask(courseId, studentId);

		openConnection.setRequestMethod("DELETE");
		openConnection.setRequestProperty("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36");
		openConnection.connect();

		return rc;
	}

	public List<TaskScore> getCourseScoreForStudent(Integer studentId) {
		List<TaskScore> taskScore = taskScoreMapper.getTaskScoreByStudentId(studentId);
//		System.out.println(taskScore.get(0).getCourse().getName() + "==" + taskScore.get(0).getTaskName()
//				+ taskScore.get(0).getTaskScore());
		return taskScore;
	}

	@Override
	public ResultCode selectCourse(Integer courseId, Integer studentId, String courseTimeColumn) {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		ResultCode rc0 = JudgeCourseInCurriculum(courseTimeColumn, studentId);
		if (rc0.getCode() == Common.SUCCESS) {
			int affectRow = courseMapper.addStudentNumToCourse(courseId);
			if (affectRow == 0) {
				rc.setCode(Common.SERVERFAILED);
				rc.setMsg("人数已满");
				return rc;
			}
			addStudentToCourse(courseId, studentId);
			updateCurriculum(courseTimeColumn, courseId, studentId);
		} else {
			rc = rc0;
		}
		return rc;
	}
}
