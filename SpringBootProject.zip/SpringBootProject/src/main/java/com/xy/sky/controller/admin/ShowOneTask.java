package com.xy.sky.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("admin")
public class ShowOneTask {

	@RequestMapping(value = "showOneTask")
	public String showOneTask(Integer studentId, String studentName, Integer courseId, String courseName,
			String taskName, String taskFileUrl, Model model) {
		model.addAttribute("studentId", studentId);
		model.addAttribute("studentName", studentName);
		model.addAttribute("courseId", courseId);
		model.addAttribute("courseName", courseName);
		model.addAttribute("taskName", "作业名:" + taskName);
		model.addAttribute("taskFileUrl", taskFileUrl);

		return "admin/oneTask.html";
	}
}
