package com.xy.sky.util;

public class CastUtil {

	@SuppressWarnings("unchecked")
	public static <T> T cast(Object obj) {

		return (T) obj;
	}

}
