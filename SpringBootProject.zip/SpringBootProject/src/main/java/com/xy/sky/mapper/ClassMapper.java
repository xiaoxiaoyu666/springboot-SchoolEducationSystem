package com.xy.sky.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.xy.sky.bean.Class;

@Mapper
public interface ClassMapper {
	String getClassName(Integer classId);

	int deleteByPrimaryKey(Integer id);

	int insert(Class record);

	int insertSelective(Class record);

	Class selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(Class record);

	int updateByPrimaryKey(Class record);
}