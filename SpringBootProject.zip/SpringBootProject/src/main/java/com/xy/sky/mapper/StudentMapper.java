package com.xy.sky.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.context.annotation.Lazy;

import com.xy.sky.bean.Student;

@Mapper
@Lazy(false)
public interface StudentMapper {

	int deleteByPrimaryKey(Integer id);

	int insert(Student record);

	int insertSelective(Student record);

	Student selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(Student record);

	int updateByPrimaryKey(Student record);

	String getStudentNameById(Integer studentId);
}