package com.xy.sky.filter;

//@WebFilter("/admin/TaskUpLoad")
//public class RequestFilter implements Filter {
//
//	String taskName;
//	String courseName;
//	String courseTeacher;
//	InputStream inputStream;
//
//	@Override
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//			throws IOException, ServletException {
//		HttpServletRequest req = (HttpServletRequest) request;
//		HttpServletResponse resp = (HttpServletResponse) response;
////		ServletInputStream inputStream = req.getInputStream();
//
//		FileItemFactory fileItemFactory = new DiskFileItemFactory();
//		ServletFileUpload servletFileUpload = new ServletFileUpload(fileItemFactory);
//		servletFileUpload.setHeaderEncoding("UTF-8");
//		servletFileUpload.setFileSizeMax(1024000);
//		try {
//			List<FileItem> fileItem = servletFileUpload.parseRequest(req);
//			for (FileItem item : fileItem) {
//				if (item.isFormField()) {
//					if (item.getFieldName().equals("taskName"))
//						this.taskName = item.getString("UTF-8");
//					if (item.getFieldName().equals("courseName"))
//						this.courseName = item.getString("UTF-8");
//					if (item.getFieldName().equals("courseTeacher"))
//						this.courseTeacher = item.getString("UTF-8");
//				} else {
//					InputStream inputStream = item.getInputStream();
//					String name = item.getName();
//					HashMap<String, InputStream> map = new HashMap<>();
//					map.put(name, inputStream);
//					req.getServletContext().setAttribute("fileStream", map);
//				}
//			}
//		} catch (FileUploadException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
////		this.inputStream = req.getInputStream();
////		byte[] requestByte = new byte[102400];
////		int read = inputStream.read(requestByte);
////		String string = new String(requestByte, 0, read);
//////		System.out.println("========" + new String(requestByte, 0, read));
////		ServletContext servletContext = req.getServletContext();
////		servletContext.setAttribute("reqInputStream", string);
//		req.getRequestDispatcher("/admin/TaskUpLoad/" + taskName + "/" + courseName + "/" + courseTeacher).forward(req,
//				resp);
//
//	}
//
//}
