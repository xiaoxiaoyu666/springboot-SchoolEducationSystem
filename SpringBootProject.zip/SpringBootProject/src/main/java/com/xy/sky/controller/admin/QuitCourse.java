package com.xy.sky.controller.admin;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("admin")
public class QuitCourse {

	@RequestMapping(value = "quitCourse")
	public String quitCourse(HttpSession session) {
		session.removeAttribute("totalPage");
		return "admin/loginSuccess.html";
	}
}
