package com.xy.sky.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.News;
import com.xy.sky.service.NewsServiceInter;
import com.xy.sky.util.CastUtil;
import com.xy.sky.util.NewsPageUtil;
import com.xy.sky.util.PageHelperUtil;
import com.xy.sky.util.PageUtil;

@Controller
public class ShowNews {

	@Autowired
	@Qualifier("NewsService")
	private NewsServiceInter newsService;

	@RequestMapping(value = "ShowNews")
	public String showNews(String thePage, String order, String loginIndex, String toCollect, HttpSession session,
			Model model) throws Exception {

		// 判断用户是否从首页登入
		if (session.getAttribute("loginIndex") == null)
			session.setAttribute("loginIndex", loginIndex);

		// 判断用户是否需要查看收藏新闻
		if (toCollect != null && toCollect.equals("true")) {
			if (session.getAttribute("toCollect") == null
					|| ((String) session.getAttribute("toCollect")).equals("false"))
				session.setAttribute("toCollect", "true");
		} else if (toCollect != null && toCollect.equals("false")) {
			if (session.getAttribute("toCollect") == null
					|| ((String) session.getAttribute("toCollect")).equals("true"))
				session.setAttribute("toCollect", "false");
		}

		PageInfo<News> pageInfo;
		try {
			// 得到分页信息
			PageHelperUtil<News> newsPageUtil = new NewsPageUtil(newsService, session, order);
			pageInfo = newsPageUtil.realPageInfo(thePage);
		} catch (NumberFormatException e) {
			pageInfo = CastUtil.cast(session.getAttribute("prePageInfo"));
		}

		// 得到分页导航栏的页面范围
		Map<String, Integer> paginationRange = PageUtil.paginationRange(pageInfo, pageInfo.getPageNum());
		Integer firstPage = paginationRange.get(PageUtil.FIRSTPAGE);
		Integer lastPage = paginationRange.get(PageUtil.LASTPAGE);

		session.setAttribute("prePageInfo", pageInfo);

		model.addAttribute("currentPage", pageInfo.getPageNum());
		model.addAttribute("news", pageInfo.getList());
		model.addAttribute("totalPages", pageInfo.getPages());
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("order", order);

		return "news.html";
	}
}
