package com.xy.sky.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.News;
import com.xy.sky.bean.NewsCollectInfo;
import com.xy.sky.bean.User;
import com.xy.sky.mapper.NewsMapper;
import com.xy.sky.service.NewsServiceInter;

@Service("NewsService")
@Transactional
/*
 * readOnly 该属性⽤于设置当前事务是否为只读事务，设置为true表⽰只读，false则表⽰可读写，默认值为false。例如：
 *
 * @Transactional(readOnly=true) rollbackFor
 * 该属性⽤于设置需要进⾏回滚的异常类数组，当⽅法中抛出指定异常数组中的异常时，则进⾏事务回滚。例如：指定单⼀异
 * 常类：@Transactional(rollbackFor=RuntimeException.class)指定多个异常类：@Transactional(
 * rollbackFor= {RuntimeException.class, Exception.class}) rollbackForClassName
 * 该属性⽤于设置需要进⾏回滚的异常类名称数组，当⽅法中抛出指定异常名称数组中的异常时，则进⾏事务回
 * 滚。例如：指定单⼀异常类名称@Transactional(rollbackForClassName=”RuntimeException”)
 * 指定多个异常类名称：
 *
 * @Transactional(rollbackForClassName={“RuntimeException”,”Exception”})
 * noRollbackFor 该属性⽤于设置不需要进⾏回滚的异常类数组，当⽅法中抛出指定异常数组中的异常时，不进⾏事务回滚。例如：指定
 * 单⼀异常类：@Transactional(noRollbackFor=RuntimeException.class)指定多个异常类：@
 * Transactional(noRollbackFor= {RuntimeException.class, Exception.class})
 * noRollbackForClassName 该属性⽤于设置不需要进⾏回滚的异常类名称数组，当⽅法中抛出指定异常名称数组中的异常时，不进⾏事
 * 务回滚。例如：指定单⼀异常类名称：@Transactional(noRollbackForClassName=”RuntimeException”)
 * 指定多个异常类名称：
 *
 * @Transactional(noRollbackForClassName={“RuntimeException”,”Exception”})
 * propagation 该属性⽤于设置事务的传播⾏为。例如：
 *
 * @Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true) isolation
 * 该属性⽤于设置底层数据库的事务隔离级别，事务隔离级别⽤于处理多事务并发的情况，通常使⽤数据库的默认隔离级别即 可，基本不需要进⾏设置 timeout
 * 该属性⽤于设置事务的超时秒数，默认值为-1表⽰永不超时 4. 事务属性 事务隔离级别
 * 隔离级别是指若⼲个并发的事务之间的隔离程度。TransactionDefinition 接⼝中定义了五个表⽰隔离级别的常量：
 * TransactionDefinition.ISOLATION_DEFAULT：这是默认值，表⽰使⽤底层数据库的默认隔离级别。对⼤部分数据库⽽⾔，
 * 通常这值就 是TransactionDefinition.ISOLATION_READ_COMMITTED。
 * TransactionDefinition.ISOLATION_READ_UNCOMMITTED：该隔离级别表⽰⼀个事务可以读取另⼀
 * 个事务修改但还没有提交的数据。 该级别不能防⽌脏读，不可重复读和幻读，因此很少使⽤该隔离级别。⽐如PostgreSQL实际上并没有此级别。
 * TransactionDefinition.ISOLATION_READ_COMMITTED：该隔离级别表⽰⼀个事务只能读取另⼀个事务已经提交的数据。
 * 该级别可以 防⽌脏读，这也是⼤多数情况下的推荐值。
 * TransactionDefinition.ISOLATION_REPEATABLE_READ：该隔离级别表⽰⼀个事务在整个过程中可以多次重复执⾏某个查询
 * ，并且每 次返回的记录都相同。该级别可以防⽌脏读和不可重复读。
 * TransactionDefinition.ISOLATION_SERIALIZABLE：所有的事务依次逐个执⾏，这样事务之间就完全不可能产⽣⼲扰，
 * 也就是说，该级 别可以防⽌脏读、不可重复读以及幻读。但是这将严重影响程序的性能。通常情况下也不会⽤到该级别。 事务传播⾏为
 * 所谓事务的传播⾏为是指，如果在开始当前事务之前，⼀个事务上下⽂已经存在，此时有若⼲选项可以指定⼀个事务性⽅法的执⾏⾏为。在
 * TransactionDefinition定义中包括了如下⼏个表⽰传播⾏为的常量：
 * TransactionDefinition.PROPAGATION_REQUIRED：如果当前存在事务，则加⼊该事务；如果当前没有事务，则创建⼀个新的事务
 * 。这 是默认值。
 * TransactionDefinition.PROPAGATION_REQUIRES_NEW：创建⼀个新的事务，如果当前存在事务，则把当前事务挂起。
 * TransactionDefinition.PROPAGATION_SUPPORTS：如果当前存在事务，则加⼊该事务；如果当前没有事务，则以⾮事务的⽅
 * 式继续 运⾏。
 * TransactionDefinition.PROPAGATION_NOT_SUPPORTED：以⾮事务⽅式运⾏，如果当前存在事务，则把当前事务挂起。
 * TransactionDefinition.PROPAGATION_NEVER：以⾮事务⽅式运⾏，如果当前存在事务，则抛出异常。
 * TransactionDefinition.PROPAGATION_MANDATORY：如果当前存在事务，则加⼊该事务；如果当前没有事务，则抛出异常。
 * TransactionDefinition.PROPAGATION_NESTED：如果当前存在事务，则创建⼀个事务作为当前事务的嵌套事务来运⾏；
 * 如果当前没有 事务，则该取值等价于TransactionDefinition.PROPAGATION_REQUIRED
 */
@Scope("prototype")
public class NewsService implements NewsServiceInter {

	@Autowired
	private NewsMapper newsMapper;

	public PageInfo<News> queryNews(Integer currentPage, String order) {
		Integer pageRecords = 3;

		PageHelper.startPage(currentPage, pageRecords);

		List<News> newsArr = null;
		if (order == null || order.equals("") || order.equals("null"))
			newsArr = newsMapper.queryNews();
		else if (order.equals("temperature"))
			newsArr = newsMapper.queryNewsOrderByTemperature();
		else if (order.equals("collect"))
			newsArr = newsMapper.queryNewsOrderByCollect();
		PageInfo<News> result = new PageInfo<>(newsArr);

		return result;
	}

	public News queryOneNews(Integer id) {

		News news = newsMapper.queryOneNews(id);

		return news;
	}

	public Integer selectTemperature(Integer id) {
		return newsMapper.selectTemperature(id);
	}

	public Integer selectCollect(Integer id) {
		return newsMapper.selectCollect(id);
	}

	public void addTemperature(Integer id) {
		newsMapper.addTemperature(id);
	}

	public void addCollect(Integer id, Integer count) {
		newsMapper.addCollect(id, count);
	}

	public Integer countCollect(Integer newsId) {
		return newsMapper.countCollect(newsId);
	}

	public void addCollectInfo(Integer userId, Integer newsId, String select) {
		newsMapper.addCollectInfo(userId, newsId, select);
	}

	public NewsCollectInfo queryCollectInfo(Integer userId, Integer newsId, String select) {
		return newsMapper.queryCollectInfo(userId, newsId, select);
	}

	public void createNews(News news) {
		newsMapper.createNews(news);
	}

	public void lostCollect(Integer userid, Integer newsid, String select) {
		newsMapper.lostCollect(userid, newsid, select);
		System.out.println(userid + "" + newsid + select);
	}

	public PageInfo<News> getCollectedNews(User user, Integer currentPage, String order) {
		Integer pageRecords = 3;

		PageHelper.startPage(currentPage, pageRecords);

		List<News> newsArr = newsMapper.getCollectedNews(user, order);

		PageInfo<News> result = new PageInfo<>(newsArr);

		return result;
	}
}
