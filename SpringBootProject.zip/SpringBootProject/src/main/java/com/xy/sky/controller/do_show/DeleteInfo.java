package com.xy.sky.controller.do_show;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Student;
import com.xy.sky.service.StudentServiceInter;

@Controller
public class DeleteInfo {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "DeleteInfo")
	public String deleteInfo(Integer id, Integer currentPage, HttpSession session) throws Exception {

		studentService.deleteByPrimaryKey(id);

		@SuppressWarnings("unchecked")
		PageInfo<Student> page = (PageInfo<Student>) session.getAttribute("page");

		// 判断删除的是否是最后一页的最后一条记录
		if (session.getAttribute("page") != null
				&& currentPage * page.getPageSize() == page.getTotal() + page.getPageSize() - 1)
			currentPage--;

		session.setAttribute("currentPage", currentPage);

		return "forward:admin/ShowDept";
	}
}
