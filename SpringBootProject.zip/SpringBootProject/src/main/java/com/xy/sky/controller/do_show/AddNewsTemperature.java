package com.xy.sky.controller.do_show;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.service.NewsServiceInter;

@RestController
public class AddNewsTemperature {

	@Autowired
	@Qualifier("NewsService")
	private NewsServiceInter newsService;

	@RequestMapping("addNewsTemperature")
	public ResultCode addNewsTemperature(Integer id) {
		System.out.println(id);
		int code = 100;
		String error = null;
		try {
			newsService.addTemperature(id);
		} catch (Exception e) {
			code = 105;
			error = "增加热度出错";
		}
		return new ResultCode(code, error);
	}
}
