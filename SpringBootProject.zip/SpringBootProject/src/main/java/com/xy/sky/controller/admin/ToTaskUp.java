package com.xy.sky.controller.admin;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping(value = "admin")
public class ToTaskUp {
	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "ToTaskUp")
	public String toTaskUp(HttpSession session) {
		List<String> allTeachersName = studentService.getAllTeachersName();
		Set<String> allCoursesName = studentService.getAllCoursesName();
		session.setAttribute("courseTeachers", allTeachersName);
		session.setAttribute("courses", allCoursesName);
		return "admin/TaskUpLoad.html";
	}
}
