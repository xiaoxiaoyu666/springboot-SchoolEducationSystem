package com.xy.sky.service;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.News;
import com.xy.sky.bean.NewsCollectInfo;
import com.xy.sky.bean.User;

public interface NewsServiceInter {

	PageInfo<News> queryNews(Integer currentPage, String order);

	News queryOneNews(Integer id);

	Integer selectTemperature(Integer id);

	Integer selectCollect(Integer id);

	void addTemperature(Integer id);

	void addCollect(Integer id, Integer count);

	Integer countCollect(Integer newsId);

	void addCollectInfo(Integer userId, Integer newsId, String select);

	NewsCollectInfo queryCollectInfo(Integer userId, Integer newsId, String select);

	void createNews(News news);

	void lostCollect(Integer userid, Integer newsid, String select);

	PageInfo<News> getCollectedNews(User user, Integer currentPage, String order);
}
