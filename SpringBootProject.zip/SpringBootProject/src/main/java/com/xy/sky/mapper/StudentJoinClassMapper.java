package com.xy.sky.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.xy.sky.bean.Student;

@Mapper
public interface StudentJoinClassMapper {

	Long getTotalRecordsCountForStudentJoinClass();

	List<Student> getStudentJoinClass();

	void upDatePsw(@Param("id") String id, @Param("ps") String ps, @Param("select") String select);

	List<Student> queryOnesStudentInfo(@Param("id") Integer id, @Param("name") String name,
			@Param("classid") Integer classid);
}
