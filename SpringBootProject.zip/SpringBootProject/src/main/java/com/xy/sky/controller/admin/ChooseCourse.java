package com.xy.sky.controller.admin;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Course;
import com.xy.sky.service.StudentServiceInter;
import com.xy.sky.util.CastUtil;
import com.xy.sky.util.CoursePageUtil;
import com.xy.sky.util.PageUtil;

@Controller
@RequestMapping("admin")
public class ChooseCourse {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "chooseCourse")
	public String chooseCourse(String thePage, Model model, HttpSession session) throws Exception {

		PageInfo<Course> courses;
		try {
			CoursePageUtil coursePageUtil = new CoursePageUtil(studentService);
			courses = coursePageUtil.realPageInfo(thePage);
			// 用户输入页码格式有误
		} catch (NumberFormatException e) {
			courses = CastUtil.cast(session.getAttribute("prePageInfo"));

		}

		// 绑定session数据
		session.setAttribute("prePageInfo", courses);
		session.setAttribute("totalPage", courses.getPages());
		session.setAttribute("thePage", courses.getPageNum());

		// 绑定网页数据
		model.addAttribute("courses", courses.getList());
		model.addAttribute("currentPage", courses.getPageNum());
		Map<String, Integer> paginationRange = PageUtil.paginationRange(courses, courses.getPageNum());
		Integer firstPage = paginationRange.get(PageUtil.FIRSTPAGE);
		Integer lastPage = paginationRange.get(PageUtil.LASTPAGE);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);

		List<Integer> arr = studentService.getChoosedCourse(Integer.parseInt((String) session.getAttribute("userId")));

		model.addAttribute("choosedCourses", arr);
		return "admin/chooseCourse.html";
	}
}
