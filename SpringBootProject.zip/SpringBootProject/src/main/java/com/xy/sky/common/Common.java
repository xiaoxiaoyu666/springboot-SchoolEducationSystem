package com.xy.sky.common;

public class Common {

	public static final int SUCCESS = 100;
	public static final int CLIENTFAILED = 106;
	public static final int SERVERFAILED = 105;
}
