package com.xy.sky.controller.do_show;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.service.StudentServiceInter;

@Controller
public class DoToUpDateInfo {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "ToUpDateInfo")
	public String ToUpDateInfo(Integer id, String name, String password, Integer classId, Integer currentPage,
			HttpServletRequest request, HttpSession session) throws Exception {
		session.setAttribute("name", name);
		session.setAttribute("psw", password);
		session.setAttribute("classId", classId);

		String className = studentService.GetClassName(classId);

		session.setAttribute("className", className);
		session.setAttribute("temp", id);
		session.setAttribute("currentPage", currentPage);

		return "forward:admin/ShowDept";
	}
}
