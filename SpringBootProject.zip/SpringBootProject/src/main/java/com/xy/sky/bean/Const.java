package com.xy.sky.bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Const {
	private static ThreadLocal<HttpServletRequest> requests = new InheritableThreadLocal<HttpServletRequest>();
	private static ThreadLocal<HttpServletResponse> responses = new InheritableThreadLocal<HttpServletResponse>();
	private static ThreadLocal<HttpSession> sessions = new InheritableThreadLocal<HttpSession>();

	public static void setSession(HttpSession value) {
		sessions.set(value);
	}

	public static HttpSession getSession() {
		return sessions.get();
	}

	public static HttpServletRequest getReq() {
		return requests.get();
	}

	public static void setReq(HttpServletRequest value) {
		requests.set(value);
	}

	public static void setRes(HttpServletResponse value) {
		responses.set(value);
	}

	public static HttpServletResponse getRes() {
		return responses.get();
	}
}
