package com.xy.sky.util;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Course;
import com.xy.sky.service.StudentServiceInter;

public class CoursePageUtil implements PageHelperUtil<Course> {
	private StudentServiceInter studentService;

	public CoursePageUtil(StudentServiceInter studentService) {
		super();
		this.studentService = studentService;

	}

	@Override
	public Integer getCurrentPage(String thePage) {
		Integer currentPage;
		if (thePage == null) {
			currentPage = 1;
		} else {
			currentPage = Integer.parseInt(thePage);
		}
		return currentPage;
	}

	@Override
	public PageInfo<Course> realPageInfo(String thePage) {
		Integer currentPage = getCurrentPage(thePage);
		PageInfo<Course> pageDemo = studentService.chooseCourse(currentPage);

		if (currentPage < 1) {
			currentPage = 1;
		} else if (currentPage > pageDemo.getPages()) {
			currentPage = pageDemo.getPages();
		}

		PageInfo<Course> pageInfo = studentService.chooseCourse(currentPage);
		return pageInfo;
	}

}
