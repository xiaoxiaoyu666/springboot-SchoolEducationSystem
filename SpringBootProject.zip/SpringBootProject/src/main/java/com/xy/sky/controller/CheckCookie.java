package com.xy.sky.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CheckCookie {
	@RequestMapping(value = "/CheckCookies")
	public String checkCookie(HttpServletRequest request, HttpServletResponse response, Model model) {
		String value = "";
		String checkedValue = "";
		Cookie[] cookies = request.getCookies();

		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if (name.equals("loginName")) {
				value = cookie.getValue();

				for (Cookie cookie1 : cookies) {
					String name1 = cookie1.getName();
					if (name1.equals("checked") && cookie1.getValue().equals(value)) {
						checkedValue = "checked";
						break;
					}
				}

				break;
			}

		}

		model.addAttribute("loginName", value);
		model.addAttribute("checked", checkedValue);
		return "login.html";
	}
}
