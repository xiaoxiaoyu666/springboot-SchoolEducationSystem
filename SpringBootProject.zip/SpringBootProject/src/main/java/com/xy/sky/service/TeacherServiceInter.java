package com.xy.sky.service;

import java.util.List;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Task;
import com.xy.sky.bean.TaskScore;

public interface TeacherServiceInter {
	List<Task> getAllStudentTasks(Integer teacherId);

	List<TaskScore> getCourseScoreForTeacher(Integer teacherId);

	ResultCode correctTask(Task task, TaskScore taskScore);
}
