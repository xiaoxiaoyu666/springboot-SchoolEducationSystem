package com.xy.sky.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.xy.sky.bean.TaskScore;

@Mapper
public interface TaskScoreMapper {

	void addTaskScore(TaskScore taskScore);

	List<TaskScore> getTaskScoreByStudentId(Integer studentId);

	List<TaskScore> getTaskScoreByCourseIds(List<Integer> courseIds);

}
