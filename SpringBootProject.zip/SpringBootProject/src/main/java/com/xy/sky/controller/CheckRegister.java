package com.xy.sky.controller;

import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@RestController
public class CheckRegister {
	public ResultCode checkRegister(String name, String id, String password1, String password2, String select,
			StudentServiceInter studentService) {

		int code = Common.SUCCESS;
		String error = null;
		if (name.equals("")) {
			error = "用户名不能为空";
			code = Common.CLIENTFAILED;
		} else if (id.equals("")) {
			error = "编号不能为空";
			code = Common.CLIENTFAILED;
		} else if (password1.equals("") || password2.equals("")) {
			error = "密码不能为空";
			code = Common.CLIENTFAILED;

		} else if (select == null) {
			error = "请选择身份";
			code = Common.CLIENTFAILED;

		} else if (password1.length() < 6 || password2.length() < 6) {
			error = "请输入正确的密码格式";
			code = Common.CLIENTFAILED;

		} else {

			password1 = DigestUtils.md5DigestAsHex(password1.getBytes());
			password2 = DigestUtils.md5DigestAsHex(password2.getBytes());

			try {
				int temp = studentService.judgeRepeatAdmin(Integer.parseInt(id), select);

				if (temp == 0) {
					if (password1.equals(password2)) {

						code = Common.SUCCESS;

					} else {
						error = "两次密码不匹配";
						code = Common.CLIENTFAILED;
					}

				} else {
					error = "用户已存在";
					code = Common.SERVERFAILED;
				}
			} catch (NumberFormatException e) {
				error = "编号格式错误";
				code = Common.CLIENTFAILED;
			}
		}
		return new ResultCode(code, error);
	}
}
