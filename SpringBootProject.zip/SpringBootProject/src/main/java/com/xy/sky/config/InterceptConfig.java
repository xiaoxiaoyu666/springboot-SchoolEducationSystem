package com.xy.sky.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.xy.sky.interceptor.AdminInterceptor;
import com.xy.sky.interceptor.TeacherInterceptor;
import com.xy.sky.interceptor.ThreadLocalInterceptor;
import com.xy.sky.interceptor.UserInterceptor;

@Configuration
public class InterceptConfig implements WebMvcConfigurer {
	// 配置过滤器
	@Override
	public void addInterceptors(InterceptorRegistry registry) {

		String[] addPathPatterns = { "/admin/**" };
		registry.addInterceptor(new UserInterceptor()).addPathPatterns(addPathPatterns);

		String[] adminPath = { "/realadmin/**" };
		InterceptorRegistration addInterceptor = registry.addInterceptor(new AdminInterceptor());
		addInterceptor.addPathPatterns(adminPath);

		String[] requestPath = { "/**" };
		registry.addInterceptor(new ThreadLocalInterceptor()).addPathPatterns(requestPath);

		String[] teacherPath = { "/teacher/**" };
		registry.addInterceptor(new TeacherInterceptor()).addPathPatterns(teacherPath);

		WebMvcConfigurer.super.addInterceptors(registry);
	}

}
