package com.xy.sky.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.xy.sky.bean.News;
import com.xy.sky.bean.NewsCollectInfo;
import com.xy.sky.bean.User;

@Mapper
public interface NewsMapper {
	public List<News> queryNews();

	public List<News> queryNewsOrderByTemperature();

	public List<News> queryNewsOrderByCollect();

	public News queryOneNews(Integer id);

	public Integer selectTemperature(Integer id);

	public Integer selectCollect(Integer id);

	public void addTemperature(Integer id);

	public void addCollect(@Param("id") Integer id, @Param("count") Integer count);

	public void addCollectInfo(@Param("userId") Integer userId, @Param("newsId") Integer newsId,
			@Param("select") String select);

	public Integer countCollect(Integer newsId);

	public NewsCollectInfo queryCollectInfo(@Param("userId") Integer userId, @Param("newsId") Integer newsId,
			@Param("select") String select);

	public void createNews(News news);

	void lostCollect(@Param("userid") Integer userid, @Param("newsid") Integer newsid, @Param("select") String select);

	List<News> getCollectedNews(@Param("user") User user, @Param("order") String order);
}
