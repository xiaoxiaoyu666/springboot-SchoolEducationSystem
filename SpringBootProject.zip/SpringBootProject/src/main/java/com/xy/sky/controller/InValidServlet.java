package com.xy.sky.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InValidServlet {
	@RequestMapping(value = "InValidServlet")
	public String inValidServlet(HttpSession session) {
		session.invalidate();
		return "redirect:/Index";
	}
}
