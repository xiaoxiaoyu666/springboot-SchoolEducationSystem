package com.xy.sky.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;

@RestController
public class CheckVerify {
//	@RequestMapping(value = "/checkVerify")
	public ResultCode checkVerify(String code, HttpSession session) {

		String error = null;
		int errorCode = 100;

		try {
			// 从session中获取随机数
			String random = (String) session.getAttribute("RANDOMVALIDATECODEKEY");
			if (random == null) {
				error = "验证码出错";
				errorCode = 105;
			}
			if (random.equals(code)) {
				error = "正确的验证码";

			} else {
				error = "错误的验证码";
				errorCode = 106;
			}
		} catch (Exception e) {
			error = "服务器出错";
			errorCode = 105;
		}
		return new ResultCode(errorCode, error);
	}
}
