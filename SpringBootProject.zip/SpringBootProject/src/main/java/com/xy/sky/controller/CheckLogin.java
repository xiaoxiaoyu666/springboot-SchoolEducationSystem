package com.xy.sky.controller;

import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@RestController
public class CheckLogin {

	public ResultCode checkLogin(String id, String password, String select, String code,
			StudentServiceInter studentService) {
		/*
		 * 需要用户输入的类型全部为String：因为用户可能会输入其他格式 首先进行数据绑定：以便用户输入有误的时候可以记住用户之前输入的内容 判断用户输入是否为空
		 * 捕捉用户输入格式错误
		 */
		String error = null;
		int errorCode = Common.SUCCESS;
		if (id == null || id.equals("")) {
			errorCode = Common.CLIENTFAILED;
			error = "用户名不能为空";

		} else if (password.equals("") || password == null) {
			errorCode = Common.CLIENTFAILED;
			error = "密码不能为空";

		} else if (select == null || select.equals("")) {
			errorCode = Common.CLIENTFAILED;
			error = "请选择身份";

		} else if (code.equals("") || code == null) {
			errorCode = Common.CLIENTFAILED;
			error = "请输入验证码";

		} else {
			password = DigestUtils.md5DigestAsHex(password.getBytes());
			try {
				if (!studentService.JudgeAdminAndPsw(Integer.parseInt(id), password, select)) {
					errorCode = Common.CLIENTFAILED;
					error = "用户名密码错误";

				} else {
					errorCode = Common.SUCCESS;
				}
			} catch (NumberFormatException e) {
				errorCode = Common.CLIENTFAILED;
				error = "用户id格式错误";
			}
		}
		return new ResultCode(errorCode, error);
	}
}
