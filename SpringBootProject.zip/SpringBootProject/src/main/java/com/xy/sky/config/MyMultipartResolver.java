package com.xy.sky.config;

//@Configuration
//public class MyMultipartResolver {
//	@Bean
//	public CommonsMultipartResolver MultipartResolver() {
//		CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver();
//
//		commonsMultipartResolver.setDefaultEncoding("UTF-8");
//		commonsMultipartResolver.setMaxUploadSize(5242800);
//		commonsMultipartResolver.setMaxUploadSizePerFile(102400);
//
//		return commonsMultipartResolver;
//	}
//}
