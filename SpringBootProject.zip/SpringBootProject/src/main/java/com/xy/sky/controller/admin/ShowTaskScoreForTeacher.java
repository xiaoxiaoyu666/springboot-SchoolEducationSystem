package com.xy.sky.controller.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.TaskScore;
import com.xy.sky.service.TeacherServiceInter;

@Controller
@RequestMapping("admin")
public class ShowTaskScoreForTeacher {

	@Autowired
	private TeacherServiceInter teacherService;

	@RequestMapping(value = "showTaskScoreForTeacher")
	public String showTaskScoreForStudent(Model model, HttpSession session) {
		Integer teacherId = Integer.parseInt((String) session.getAttribute("userId"));
		List<TaskScore> allStudentTasks = teacherService.getCourseScoreForTeacher(teacherId);
		model.addAttribute("tasks", allStudentTasks);
		return "admin/taskScoreForTeacher.html";
	}

}
