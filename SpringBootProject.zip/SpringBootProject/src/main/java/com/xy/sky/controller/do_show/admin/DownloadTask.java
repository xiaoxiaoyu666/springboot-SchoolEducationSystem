package com.xy.sky.controller.do_show.admin;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.Const;

@RestController
@RequestMapping("teacher")
public class DownloadTask {

	@RequestMapping(value = "downloadTask")
	public void downloadTask(String taskUrl, String taskName, HttpServletRequest req, HttpServletResponse response) {
		Runnable run = new Runnable() {
			@Override
			public void run() {
				File file = new File(taskUrl + taskName);

				String fileName = file.getName();

				HttpServletResponse resp = Const.getRes();
				try {
					// 本地文件下载
//					FileInputStream fis = new FileInputStream(file);
//					InputStream input = new BufferedInputStream(fis);
//
//					String fileType = URLConnection.guessContentTypeFromStream(input);
//
//					resp.setContentType(fileType);
//					// 告诉浏览器这是附件，用于下载
//					resp.setHeader("Content-Disposition",
//							"attament;filename=" + URLEncoder.encode(fileName, "UTF-8"));
//
//					OutputStream output = resp.getOutputStream();
//					IOUtils.copy(input, output);
//					input.close();
//					output.close();
//					fis.close();

					// 访问远程服务器下载
					String fileurl = file.getPath().replaceAll("\\\\", "/");
					URL url = new URL(taskUrl + URLEncoder.encode(taskName, "utf-8"));
					HttpURLConnection openConnection = (HttpURLConnection) url.openConnection();
					openConnection.setRequestMethod("GET");
					openConnection.setRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36");
					openConnection.connect();
					InputStream inputStream = openConnection.getInputStream();

					String fileType = URLConnection.guessContentTypeFromStream(inputStream);
					resp.setContentType(fileType);
					// 告诉浏览器这是附件，用于下载
					resp.setHeader("Content-Disposition", "attament;filename=" + URLEncoder.encode(fileName, "UTF-8"));

					OutputStream output = resp.getOutputStream();
					IOUtils.copy(inputStream, output);
//					inputStream.close();
//					output.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		};
		Thread th = new Thread(run);
		th.start();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
