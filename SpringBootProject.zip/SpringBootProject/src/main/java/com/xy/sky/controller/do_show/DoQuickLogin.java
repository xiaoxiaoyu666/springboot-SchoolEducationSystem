package com.xy.sky.controller.do_show;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.controller.CheckLogin;
import com.xy.sky.controller.CheckVerify;
import com.xy.sky.service.StudentServiceInter;

@RestController
public class DoQuickLogin {

	@Autowired
	@Qualifier("studentSerivce")
	private StudentServiceInter studentService;

	@RequestMapping(value = "DoQuickLogin")
	public ResultCode doQuickLogin(String id, String password, String select, String code, HttpSession session,
			Model model) throws NumberFormatException, SQLException {
		int errorCode = 100;
		String error = null;

		model.addAttribute("userid", id);
		model.addAttribute("password", password);
		try {
			if (select.equals("student")) {
				model.addAttribute("student", "checked");
			} else if (select.equals("teacher")) {
				model.addAttribute("teacher", "checked");
			} else {
				model.addAttribute("admin", "checked");
			}
		} catch (NullPointerException e) {
		}

		CheckLogin cl = new CheckLogin();
		CheckVerify cv = new CheckVerify();

		ResultCode resultcl = cl.checkLogin(id, password, select, code, studentService);
		ResultCode resultcv = cv.checkVerify(code, session);

		if (resultcl.getCode() == Common.SUCCESS && resultcv.getCode() == Common.SUCCESS) {
			session.setAttribute("userId", id);
			session.setAttribute("select", select);

			session.setAttribute("user", new User(Integer.parseInt(id), password, select));

			session.setAttribute("text", studentService.GetAdminName(new User(Integer.parseInt(id), password, select)));

			errorCode = 100;
			error = null;
		} else {
			if (resultcl.getCode() != Common.SUCCESS) {
				errorCode = resultcl.getCode();
				error = resultcl.getMsg();
			} else {
				errorCode = resultcv.getCode();
				error = resultcv.getMsg();
			}
		}
		return new ResultCode(errorCode, error);
	}
}
