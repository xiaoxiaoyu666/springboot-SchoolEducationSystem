package com.xy.sky.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.context.annotation.Lazy;

@Mapper
@Lazy(false)
public interface TeacherMapper {

	List<String> getAllTeachersName();

}
