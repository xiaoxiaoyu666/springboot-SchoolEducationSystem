package com.xy.sky.bean;

public class News {
	private Integer id;
	private String title;
	private String content;
	private Integer temperature;
	private Integer collect;
	private String publish_time;

	public News(String title, String content, String publish_time) {
		super();
		this.title = title;
		this.content = content;
		this.publish_time = publish_time;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getTemperature() {
		return temperature;
	}

	public void setTemperature(Integer temperature) {
		this.temperature = temperature;
	}

	public Integer getCollect() {
		return collect;
	}

	public void setCollect(Integer collect) {
		this.collect = collect;
	}

	public String getPublish_time() {
		return publish_time;
	}

	public void setPublish_time(String publishTime) {
		this.publish_time = publishTime;
	}

}
