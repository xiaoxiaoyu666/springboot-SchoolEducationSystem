package com.xy.sky.util;

import java.util.HashMap;
import java.util.Map;

import com.github.pagehelper.PageInfo;

public class PageUtil {
	public final static String FIRSTPAGE = "firstPage";
	public final static String LASTPAGE = "lastPage";

	public static Map<String, Integer> paginationRange(PageInfo<?> pageInfo, Integer currentPage) {
		// 分页导航栏显示的第一个页面和第最后一个页面
		Integer firstPage = pageInfo.getPageNum() > 2 ? pageInfo.getPageNum() - 2 : 1;
		Integer lastPage = pageInfo.getPageNum() <= pageInfo.getPages() - 2 ? currentPage + 2 : pageInfo.getPages();

		Map<String, Integer> map = new HashMap<String, Integer>();

		map.put(FIRSTPAGE, firstPage);
		map.put(LASTPAGE, lastPage);
		return map;
	}

}
