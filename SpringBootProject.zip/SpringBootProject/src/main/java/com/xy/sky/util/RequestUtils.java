package com.xy.sky.util;

import javax.servlet.ServletInputStream;

public class RequestUtils {

	private static ServletInputStream requestInput;

	public static ServletInputStream getRequestInput() {
		return requestInput;
	}

	public static void setRequestInput(ServletInputStream requestInput) {
		RequestUtils.requestInput = requestInput;
	}

}
