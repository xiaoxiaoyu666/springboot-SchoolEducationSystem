package com.xy.sky.controller.do_show;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.service.impl.NewsService;

@RestController
public class DoLostCollect {

	@Autowired
	private NewsService newsService;

	@RequestMapping(value = "doLostCollect")
	public ResultCode doLostCollect(Integer userid, Integer newsid, String select) {

		ResultCode rc = null;
		rc = new ResultCode(100, null);
		try {
			newsService.lostCollect(userid, newsid, select);
		} catch (Exception e) {
			e.printStackTrace();
			rc.setCode(105);
			rc.setMsg("取消收藏错误");
		}
		return rc;

	}
}
