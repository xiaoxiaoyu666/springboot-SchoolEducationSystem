package com.xy.sky.bean;

public class Student {
	private Integer id;

	private String name;

	private Integer classid;

	private String password;

	private String sex;

	private Class cla;

	public Student() {
		// 匹配的类中没有无参构造时mybatis会默认匹配类中的有参构造的参数
	}

	public Student(Integer id, String name, Integer classid, String password, String sex, Class cla) {
		super();
		this.id = id;
		this.name = name;
		this.classid = classid;
		this.password = password;
		this.sex = sex;
		this.cla = cla;
	}

	public Class getCla() {
		return cla;
	}

	public void setCla(Class cla) {
		this.cla = cla;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public Integer getClassid() {
		return classid;
	}

	public void setClassid(Integer classid) {
		this.classid = classid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password == null ? null : password.trim();
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex == null ? null : sex.trim();
	}
}