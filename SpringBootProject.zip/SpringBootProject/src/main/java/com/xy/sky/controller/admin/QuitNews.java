package com.xy.sky.controller.admin;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("admin")
public class QuitNews {

	@RequestMapping(value = "quitNews")
	public String quitNews(HttpSession session) {
		session.removeAttribute("toCollect");
		return "admin/loginSuccess.html";
	}

}
