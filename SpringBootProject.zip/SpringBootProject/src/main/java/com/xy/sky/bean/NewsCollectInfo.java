package com.xy.sky.bean;

public class NewsCollectInfo {
	private Integer studentId;
	private Integer newsId;
	private String select;

	public NewsCollectInfo(Integer studentId, Integer newsId, String select) {
		super();
		this.studentId = studentId;
		this.newsId = newsId;
		this.select = select;
	}

	public String getSelect() {
		return select;
	}

	public void setSelect(String select) {
		this.select = select;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getNewsId() {
		return newsId;
	}

	public void setNewsId(Integer newsId) {
		this.newsId = newsId;
	}

}
