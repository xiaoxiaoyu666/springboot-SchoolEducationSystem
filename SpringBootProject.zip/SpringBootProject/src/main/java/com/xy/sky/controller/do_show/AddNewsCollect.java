package com.xy.sky.controller.do_show;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.service.NewsServiceInter;

@RestController
public class AddNewsCollect {

	@Autowired
	@Qualifier("NewsService")
	private NewsServiceInter newsService;

	@RequestMapping(value = "addNewsCollect")
	public ResultCode addNewsCollect(Integer newsId, Integer userId, String select, HttpSession session) {
		int code = 100;
		String error = null;

		try {
			newsService.addCollectInfo(userId, newsId, select);
			Integer count = newsService.countCollect(newsId);
			newsService.addCollect(newsId, count);
		} catch (Exception e) {
			e.printStackTrace();
			code = 105;
			error = "收藏错误";
		}

		return new ResultCode(code, error);
	}
}
