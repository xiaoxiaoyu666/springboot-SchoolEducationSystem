package com.xy.sky.controller.do_show.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@RestController
@RequestMapping("admin")
public class DeleteTask {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "deleteTask")
	public ResultCode deleteTask(Integer courseId, String fileUrl, String taskName, HttpSession session) {
		User student = (User) session.getAttribute("user");
		Integer studentId = student.getId();
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		try {
			rc = studentService.deleteTask(courseId, studentId, fileUrl, taskName);
		} catch (Exception e) {
			rc = new ResultCode(Common.SERVERFAILED, "删除错误");
		}
		return rc;
	}
}
