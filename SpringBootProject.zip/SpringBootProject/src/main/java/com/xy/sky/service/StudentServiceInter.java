package com.xy.sky.service;

import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Course;
import com.xy.sky.bean.Curriculum;
import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Student;
import com.xy.sky.bean.Task;
import com.xy.sky.bean.TaskScore;
import com.xy.sky.bean.User;

public interface StudentServiceInter {
//	public Student queryStudentById(Integer id);

	public int judgeRepeatAdmin(Integer id, String select);

	public PageInfo<Student> queryByPageForStudentJoinClass(Integer currentPage);

	public boolean upPassword(String id, String p1, String p2, String select);

	public void DoUpDateStudentInfo(Student st);

	public String GetClassName(Integer classId);

	public boolean JudgeAdminAndPsw(Integer id, String password, String select);

	public String GetAdminName(User user);

	public PageInfo<Student> queryOnesStudentInfo(Integer id, String name, Integer classid, Integer currentPage);

	void deleteByPrimaryKey(Integer id);

	void addInfo(User user, String name);

	PageInfo<Course> chooseCourse(Integer currentPage);

	void addStudentToCourse(Integer courseId, Integer studentId);

	List<Integer> getChoosedCourse(Integer studentId);

	void updateCurriculum(String courseTimeColumn, Integer courseId, Integer studentId);

	ResultCode JudgeCourseInCurriculum(String courseTimeColumn, Integer studentId);

	ResultCode JudgeHaveCurriculum(Integer studentId);

	List<Curriculum> getCurriculum(Integer studentId);

	ResultCode UpLoadTask(String teacherName, String courseName, Integer studentId, String taskName, String url,
			MultipartFile upLoadFile) throws Exception;

	List<String> getAllTeachersName();

	Set<String> getAllCoursesName();

	List<Task> queryOneStudentTask(Integer studentId);

	ResultCode deleteTask(Integer courseId, Integer studentId, String fileUrl, String taskName) throws Exception;

	List<TaskScore> getCourseScoreForStudent(Integer studentId);

	ResultCode selectCourse(Integer courseId, Integer studentId, String courseTimeColumn);

}
