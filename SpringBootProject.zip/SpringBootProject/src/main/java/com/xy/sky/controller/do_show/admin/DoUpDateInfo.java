package com.xy.sky.controller.do_show.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Student;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@RestController
@RequestMapping("realadmin")
public class DoUpDateInfo {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "DoUpDateStudentInfo")
	public ResultCode DoUpDateStudentInfo(String id, String name, String password, String classid,
			HttpServletRequest request, HttpSession session) throws Exception {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		try {
			password = DigestUtils.md5DigestAsHex(password.getBytes());
			int studentId = Integer.parseInt(id);
			int classId = Integer.parseInt(classid);
			Student student = new Student();
			student.setId(studentId);
			student.setName(name);
			student.setPassword(password);
			student.setClassid(classId);
			studentService.DoUpDateStudentInfo(student);
		} catch (NumberFormatException e) {
			rc.setCode(Common.CLIENTFAILED);
			rc.setMsg("请输入正确的格式");

		} catch (Exception e) {
			e.printStackTrace();
			rc.setCode(Common.SERVERFAILED);
			rc.setMsg("修改错误");
		}

		// 重置页码
		session.removeAttribute("temp");

		return rc;
	}
}
