package com.xy.sky.controller.admin;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Student;
import com.xy.sky.service.StudentServiceInter;
import com.xy.sky.util.CastUtil;
import com.xy.sky.util.PageHelperUtil;
import com.xy.sky.util.PageUtil;
import com.xy.sky.util.StuInfoPageUtil;

@Controller
@RequestMapping("admin")
public class ShowDept {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "ShowDept")
	public String showDept(String thePage, String select, HttpSession session, HttpServletRequest request,
			HttpServletResponse response, Model model) throws Exception {
		PageInfo<Student> pageInfo;
		try {
			// 得到分页信息
			PageHelperUtil<Student> pageUtil = new StuInfoPageUtil(studentService, session);
			pageInfo = pageUtil.realPageInfo(thePage);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			pageInfo = CastUtil.cast(session.getAttribute("prePageInfo"));
		}

		// 得到分页导航栏的页面范围
		Map<String, Integer> paginationRange = PageUtil.paginationRange(pageInfo, pageInfo.getPageNum());
		Integer firstPage = paginationRange.get(PageUtil.FIRSTPAGE);
		Integer lastPage = paginationRange.get(PageUtil.LASTPAGE);

		session.setAttribute("prePageInfo", pageInfo);

		model.addAttribute("select", (String) session.getAttribute("select"));
		model.addAttribute("stus", pageInfo.getList());
		model.addAttribute("currentPage", pageInfo.getPageNum());
		model.addAttribute("totalPages", pageInfo.getPages());
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		if (session.getAttribute("error") != null) {
			model.addAttribute("error", session.getAttribute("error"));
		}
		session.removeAttribute("error");

		// temp:记录要修改的studentId
		if (session.getAttribute("temp") != null)
			model.addAttribute("temp", session.getAttribute("temp"));

		model.addAttribute("name", session.getAttribute("name"));
		model.addAttribute("psw", session.getAttribute("psw"));
		model.addAttribute("classId", session.getAttribute("classId"));
		session.removeAttribute("temp");
		session.removeAttribute("id");
		session.removeAttribute("name");
		session.removeAttribute("psw");
		session.removeAttribute("classId");

		model.addAttribute("qid", session.getAttribute("qid"));
		model.addAttribute("qname", session.getAttribute("qname"));
		model.addAttribute("qclassId", session.getAttribute("qclassId"));

		return "admin/Dept.html";
	}
}
