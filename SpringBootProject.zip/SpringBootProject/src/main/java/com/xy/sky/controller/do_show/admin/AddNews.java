package com.xy.sky.controller.do_show.admin;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.News;
import com.xy.sky.bean.ResultCode;
import com.xy.sky.common.Common;
import com.xy.sky.service.impl.NewsService;

@RestController
@RequestMapping("realadmin")
public class AddNews {

	@Autowired
	private NewsService newsService;

	@RequestMapping(value = "addNews")
	public ResultCode addNews(String newsName, String newsContent, HttpSession session, Model model) {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		if (newsContent == null || newsContent.equals("")) {
			rc.setCode(Common.CLIENTFAILED);
			rc.setMsg("请输入新闻内容");
		} else {
			Date date = new Date();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String publishTime = format.format(date);
			News news = new News(newsName, newsContent, publishTime);
			newsService.createNews(news);
		}

		return rc;
	}
}
