package com.xy.sky.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ToUpPsw {
	@RequestMapping(value = "ToUpPsw")
	public String toUpPsw() {
		return "UpPsword.html";
	}
}
