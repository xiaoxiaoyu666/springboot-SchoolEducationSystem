package com.xy.sky.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.context.annotation.Lazy;

import com.xy.sky.bean.User;

@Mapper
@Lazy(false)
public interface UserMapper {

	String getAdminName(User user);

	List<Integer> getAdminIds(String select);

	String getPsword(User user);

	void addInfo(@Param("user") User user, @Param("name") String name);

	void deleteInfo(Integer id);

	void upDatePsw(User user);

	void UpDateBirthday(@Param("birthday") Date birthday, @Param("select") String select, @Param("id") Integer id);

}
