package com.xy.sky.util;

import com.github.pagehelper.PageInfo;

public interface PageHelperUtil<E> {
	Integer getCurrentPage(String thePage);

	PageInfo<E> realPageInfo(String thePage);

}
