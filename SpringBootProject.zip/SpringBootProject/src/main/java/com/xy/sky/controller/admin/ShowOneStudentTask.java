package com.xy.sky.controller.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.Task;
import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping("admin")
public class ShowOneStudentTask {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "showOneStudentTask")
	public String showOneStudentTask(HttpSession session, Model model) {
		Integer studentId = Integer.parseInt((String) session.getAttribute("userId"));
		List<Task> tasks = studentService.queryOneStudentTask(studentId);
		model.addAttribute("tasks", tasks);
		return "admin/oneStudentTask.html";
	}
}
