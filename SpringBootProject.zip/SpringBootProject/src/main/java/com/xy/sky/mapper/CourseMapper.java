package com.xy.sky.mapper;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.xy.sky.bean.Course;

@Mapper
public interface CourseMapper {
	List<Course> courseJoinTeacher();

	int addStudentNumToCourse(Integer courseId);

	void addCourseOfStudent(@Param("courseId") Integer courseId, @Param("studentId") Integer studentId);

	List<Integer> getChoosedCourse(Integer studentId);

	void addCurriculum(@Param("courseTimeColumn") String courseTimeColumn, @Param("courseId") Integer courseId,
			@Param("studentId") Integer studentId);

	void addCourseAtTime(@Param("courseTimeColumn") String courseTimeColumn, @Param("courseId") Integer courseId,
			@Param("studentId") Integer studentId);

	List<Integer> querryStudentIdInCurriculum();

	String querryCourseAtTime(@Param("courseTimeColumn") String courseTimeColumn,
			@Param("studentId") Integer studentId);

	String getCourseNameById(Integer courseId);

	Set<String> getAllCoursesName();

	List<Integer> getCourseIdByTeacherAndCourse(@Param("courseName") String courseName,
			@Param("teacherId") Integer teacherId);

	List<Integer> getTeacherIdsByName(String teacherName);

	List<Integer> getStudentIdByCourseId(Integer courseId);

	List<Integer> getCourseIdsByTeacherId(Integer teacherId);
}
