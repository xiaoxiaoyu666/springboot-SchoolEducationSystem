package com.xy.sky.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.News;
import com.xy.sky.bean.User;
import com.xy.sky.service.NewsServiceInter;

@Controller
public class ShowOneNews {

	@Autowired
	@Qualifier("NewsService")
	private NewsServiceInter newsService;

	@RequestMapping(value = "ShowOneNews")
	public String showOneNews(Integer id, Integer currentPage, String order, Model model, HttpSession session) {

		News news = newsService.queryOneNews(id);

		// 判断用户是否登入
		User user = (User) session.getAttribute("user");
		if (user != null) {
			if (newsService.queryCollectInfo(user.getId(), id, user.getSelect()) != null) {
				model.addAttribute("isCollect", "true");
			} else {
				model.addAttribute("isCollect", "false");
			}
			model.addAttribute("userId", user.getId());
			model.addAttribute("select", user.getSelect());

		} else {
			model.addAttribute("userId", null);
		}

		model.addAttribute("newsId", id);
		model.addAttribute("title", news.getTitle());
		model.addAttribute("content", news.getContent());
		model.addAttribute("publishTime", news.getPublish_time());
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("order", order);

		return "oneNews.html";
	}
}
