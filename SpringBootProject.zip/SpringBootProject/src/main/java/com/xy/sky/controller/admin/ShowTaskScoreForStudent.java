package com.xy.sky.controller.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.TaskScore;
import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping("admin")
public class ShowTaskScoreForStudent {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "showTaskScoreForStudent")
	public String showTaskScoreForStudent(Model model, HttpSession session) {
		Integer studentId = Integer.parseInt((String) session.getAttribute("userId"));
		List<TaskScore> courseScoreForStudent = studentService.getCourseScoreForStudent(studentId);
		model.addAttribute("tasks", courseScoreForStudent);
		return "admin/taskScoreForStudent.html";
	}

}
