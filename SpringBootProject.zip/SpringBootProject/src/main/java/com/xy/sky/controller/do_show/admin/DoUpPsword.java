package com.xy.sky.controller.do_show.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping("admin")
public class DoUpPsword {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "UpPsword")
	public String UpPsword(String newPsw1, String newPsw2, HttpServletRequest request, HttpSession session, Model model)
			throws Exception {

		if (newPsw1.equals("") || newPsw2.equals("")) {
			model.addAttribute("error", "请输入密码");
			return "UpPsword.html";
		} else if (newPsw1.length() < 6 || newPsw2.length() < 6) {
			model.addAttribute("error", "请正确输入密码格式");
			return "UpPsword.html";
		} else {
			String id = session.getAttribute("userId").toString();
			String select = (String) session.getAttribute("select");

			newPsw1 = DigestUtils.md5DigestAsHex(newPsw1.getBytes());
			newPsw2 = DigestUtils.md5DigestAsHex(newPsw2.getBytes());

			boolean temp = studentService.upPassword(id, newPsw1, newPsw2, select);

			if (!temp) {
				String error = "两次密码不一样";
				model.addAttribute("error", error);
				return "UpPsword.html";
			} else {

				return "UpPswSuccess.html";

			}
		}

	}
}
