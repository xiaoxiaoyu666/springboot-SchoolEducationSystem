package com.xy.sky.bean;

public class Course {

	private String name;
	private Integer id;
	private Integer teacherId;
	private String date;
	private Integer num;
	private Teacher teacher;

	public Course() {
	};

	public Course(String name, Integer id, Integer teacherId, String date, Integer num) {
		super();
		this.name = name;
		this.id = id;
		this.teacherId = teacherId;
		this.date = date;
		this.num = num;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTeacherId() {
		return teacherId;
	}

	public void setTeacher(Integer teacherId) {
		this.teacherId = teacherId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}
}
