package com.xy.sky.controller.do_show.admin;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Student;
import com.xy.sky.service.StudentServiceInter;
import com.xy.sky.util.StuInfoPageUtil;

//模糊查询
@Controller
@RequestMapping("admin")
public class DoQueryStudentInfo {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "DoQueryStudentInfo", method = RequestMethod.GET)
	public String doQueryStudentInfo(String id, String name, String classid, HttpSession session) throws IOException {
		session.setAttribute("qid", id);
		session.setAttribute("qname", name);
		session.setAttribute("qclassId", classid);
		try {
			StuInfoPageUtil stutil = new StuInfoPageUtil(studentService, session);
			Map<String, Object> doQuery = stutil.doQuery(id, classid, name);

			@SuppressWarnings("unchecked")
			PageInfo<Student> pageInfo = (PageInfo<Student>) doQuery.get(StuInfoPageUtil.PAGEINFO);
			session.setAttribute("mbstudent", (Student) doQuery.get(StuInfoPageUtil.STUDENT));
			session.setAttribute("pageInfo", pageInfo);
			session.setAttribute("pages", pageInfo.getPages());
		} catch (NumberFormatException e) {
			session.setAttribute("error", "输入格式有误");
		}
		return "forward:/admin/ShowDept";
	}
}
