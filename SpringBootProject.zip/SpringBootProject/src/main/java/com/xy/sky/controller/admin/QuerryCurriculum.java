package com.xy.sky.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.Curriculum;
import com.xy.sky.bean.ResultCode;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping("admin")
public class QuerryCurriculum {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "querryCurriculum")
	public String querryCurriculum(Integer studentId, Model model) {
		ResultCode judgeHaveCurriculum = studentService.JudgeHaveCurriculum(studentId);
		if (judgeHaveCurriculum.getCode() != Common.SUCCESS) {
			model.addAttribute("error", judgeHaveCurriculum.getMsg());
			return "admin/loginSuccess.html";
		} else {
			List<Curriculum> curriculum = studentService.getCurriculum(studentId);
			model.addAttribute("curriculum", curriculum);
			return "admin/showCurriculum.html";
		}

	}
}
