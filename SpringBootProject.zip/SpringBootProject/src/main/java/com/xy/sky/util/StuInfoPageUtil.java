package com.xy.sky.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.github.pagehelper.PageInfo;
import com.xy.sky.bean.Student;
import com.xy.sky.service.StudentServiceInter;

public class StuInfoPageUtil implements PageHelperUtil<Student> {
	public final static String STUDENT = "student";
	public final static String PAGEINFO = "pageInfo";

	private StudentServiceInter studentService;
	private HttpSession session;

	public StuInfoPageUtil(StudentServiceInter studentService, HttpSession session) {
		super();
		this.studentService = studentService;
		this.session = session;
	}

	@Override
	public PageInfo<Student> realPageInfo(String thePage) {
		PageInfo<Student> result;
		PageInfo<Student> prePage;
		Integer currentPage = getCurrentPage(thePage);
		// 判断是否有模糊查询绑定的数据
		if (session.getAttribute("pageInfo") == null) {
			prePage = studentService.queryByPageForStudentJoinClass(currentPage);
		} else {
			Student st = (Student) session.getAttribute("mbstudent");
			prePage = studentService.queryOnesStudentInfo(st.getId(), st.getName(), st.getClassid(), currentPage);
		}

		if (currentPage <= 1) {
			currentPage = 1;
		} else if (currentPage > prePage.getPages()) {
			currentPage = prePage.getPages();
		}

		// 判断是否有模糊查询绑定的数据
		if (session.getAttribute("pageInfo") == null) {
			result = studentService.queryByPageForStudentJoinClass(currentPage);
		} else {
			Student st = (Student) session.getAttribute("mbstudent");
			result = studentService.queryOnesStudentInfo(st.getId(), st.getName(), st.getClassid(), currentPage);

		}
		return result;
	}

	public Map<String, Object> doQuery(String id, String classid, String name) throws IOException {
		Integer id1, classid1;
		if (id.equals("")) {
			id1 = null;
		} else {
			id1 = Integer.parseInt(id);
		}

		if (classid.equals("")) {
			classid1 = null;
		} else {
			classid1 = Integer.parseInt(classid);
		}

		PageInfo<Student> pageInfo = studentService.queryOnesStudentInfo(id1, name, classid1, 1);
		Student student = new Student();
		student.setId(id1);
		student.setName(name);
		student.setClassid(classid1);

		HashMap<String, Object> map = new HashMap<String, Object>();

		map.put(STUDENT, student);
		map.put(PAGEINFO, pageInfo);
		return map;
	}

	@Override
	public Integer getCurrentPage(String thePage) {
		Integer currentPage;
		if (thePage != null) {
			currentPage = Integer.parseInt((String) thePage);
		} else if (session.getAttribute("currentPage") != null) {
			currentPage = (Integer) session.getAttribute("currentPage");
		} else {
			currentPage = 1;
		}
		return currentPage;
	}

}
