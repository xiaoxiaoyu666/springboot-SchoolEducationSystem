package com.xy.sky.controller.do_show;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.controller.CheckRegister;
import com.xy.sky.service.StudentServiceInter;

@Controller
public class DoRegister {

	@Autowired
	@Qualifier("studentSerivce")
	StudentServiceInter studentService;

	@RequestMapping(value = "DoRegister")
	public String Register(String admin, String id, String psword, String psword2, String select, Model model,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		CheckRegister cr = new CheckRegister();
		ResultCode resultcr = cr.checkRegister(admin, id, psword, psword2, select, studentService);
		if (resultcr.getCode() == Common.SUCCESS) {
			User user = new User(Integer.parseInt(id), DigestUtils.md5DigestAsHex(psword.getBytes()), select);

			model.addAttribute("error", "注册成功");

			studentService.addInfo(user, admin);

			Cookie nameCookie = new Cookie("loginName", id);
			response.addCookie(nameCookie);

			return "RegSuccess.html";
		} else {
			model.addAttribute("error", resultcr.getMsg());

			return "Register.html";
		}
	}
}
