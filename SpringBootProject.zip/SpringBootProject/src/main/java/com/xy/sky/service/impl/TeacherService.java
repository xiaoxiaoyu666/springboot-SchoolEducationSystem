package com.xy.sky.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.xy.sky.bean.Course;
import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Student;
import com.xy.sky.bean.Task;
import com.xy.sky.bean.TaskScore;
import com.xy.sky.common.Common;
import com.xy.sky.mapper.CourseMapper;
import com.xy.sky.mapper.StudentMapper;
import com.xy.sky.mapper.TaskMapper;
import com.xy.sky.mapper.TaskScoreMapper;
import com.xy.sky.service.StudentServiceInter;
import com.xy.sky.service.TeacherServiceInter;

@Service
@Scope("prototype")
public class TeacherService implements TeacherServiceInter {
	@Autowired
	private StudentMapper studentMapper;
	@Autowired
	private CourseMapper courseMapper;
	@Autowired
	private TaskMapper taskMapper;
	@Autowired
	private TaskScoreMapper taskScoreMapper;
	@Autowired
	private StudentServiceInter studentService;

	public List<Task> getAllStudentTasks(Integer teacherId) {
		List<Integer> courseIds = courseMapper.getCourseIdsByTeacherId(teacherId);
		List<Task> allStudentTasks = taskMapper.getAllStudentTask(courseIds);
		for (Task studentTask : allStudentTasks) {
			String studentName = studentMapper.getStudentNameById(studentTask.getStudentId());
			String courseName = courseMapper.getCourseNameById(studentTask.getCourseId());

			Student student = new Student();
			student.setName(studentName);
			Course course = new Course();
			course.setName(courseName);
			studentTask.setCourse(course);
			studentTask.setStudent(student);
		}
		return allStudentTasks;
	}

	public List<TaskScore> getCourseScoreForTeacher(Integer teacherId) {
		List<Integer> courseIds = courseMapper.getCourseIdsByTeacherId(teacherId);
		List<TaskScore> taskScoreByCourseIds = taskScoreMapper.getTaskScoreByCourseIds(courseIds);
		return taskScoreByCourseIds;
	}

	public ResultCode correctTask(Task task, TaskScore taskScore) {
		ResultCode rc = new ResultCode(Common.SUCCESS, "批改成功");
		try {
			taskScoreMapper.addTaskScore(taskScore);
			studentService.deleteTask(task.getCourseId(), task.getStudentId(), task.getTaskFileUrl(),
					task.getTaskName());
		} catch (Exception e) {
			rc.setCode(Common.SERVERFAILED);
			rc.setMsg("发生错误");
		}

		return rc;
	}
}
