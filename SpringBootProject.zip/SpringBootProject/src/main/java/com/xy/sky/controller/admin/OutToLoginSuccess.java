package com.xy.sky.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("admin")
public class OutToLoginSuccess {

	@RequestMapping(value = "outToLoginSuccess")
	public String outToLoginSuccess() {
		return "admin/loginSuccess.html";
	}
}
