package com.xy.sky.controller.do_show.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@RestController
@RequestMapping("admin")
public class DoChooseCourse {

	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping(value = "DoChooseCourse")
	public ResultCode doChooseCourse(Integer courseId, String courseTimeColumn, HttpSession session) {
		ResultCode rc = new ResultCode(Common.SUCCESS, "");
		User user = (User) session.getAttribute("user");
		Integer studentId = user.getId();
		// 禁止同一个同步多线程进行选课操作
		synchronized (session.getAttribute("user")) {
			try {
				rc = studentService.selectCourse(courseId, studentId, courseTimeColumn);
			} catch (Exception e) {
				rc.setCode(Common.SERVERFAILED);
				rc.setMsg(e.getCause().toString());
			}
		}

		return rc;
	}
}
