package com.xy.sky.controller.do_show.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.Task;
import com.xy.sky.bean.TaskScore;
import com.xy.sky.service.TeacherServiceInter;

@RestController
@RequestMapping("teacher")
public class CorrectTask {

	@Autowired
	private TeacherServiceInter teacherService;

	@RequestMapping(value = "correctTask")
	public ResultCode correctTask(Integer studentId, Integer courseId, String taskName, Integer taskScore,
			String taskUrl) {
		Task task = new Task(studentId, courseId, taskName, taskUrl);
		TaskScore taskScoreObject = new TaskScore(studentId, taskName, courseId, taskScore);
		ResultCode correctTask = teacherService.correctTask(task, taskScoreObject);
		return correctTask;
	}

}
