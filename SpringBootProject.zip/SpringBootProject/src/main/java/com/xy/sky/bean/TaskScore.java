package com.xy.sky.bean;

public class TaskScore {

	private Integer studentId;
	private String taskName;
	private Integer courseId;
	private Integer taskScore;
	private Student student;
	private Course course;

	public TaskScore() {

	}

	public TaskScore(Integer studentId, String taskName, Integer courseId, Integer taskScore) {
		super();
		this.studentId = studentId;
		this.taskName = taskName;
		this.courseId = courseId;
		this.taskScore = taskScore;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public Integer getTaskScore() {
		return taskScore;
	}

	public void setTaskScore(Integer taskScore) {
		this.taskScore = taskScore;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}
