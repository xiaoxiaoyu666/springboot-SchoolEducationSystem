package com.xy.sky.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.xy.sky.bean.Task;

@Mapper
public interface TaskMapper {
	void addTask(Task task);

	List<Task> querryTaskByStudentId(Integer studentId);

	void deleteTask(@Param("courseId") Integer courseId, @Param("studentId") Integer studentId);

	List<Task> getAllStudentTask(List<Integer> courseIds);

}
