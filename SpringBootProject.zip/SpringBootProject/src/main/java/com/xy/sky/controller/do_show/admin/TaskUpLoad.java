package com.xy.sky.controller.do_show.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.common.Common;
import com.xy.sky.service.StudentServiceInter;

@Controller
@RequestMapping("admin")
public class TaskUpLoad {
	@Autowired
	private StudentServiceInter studentService;

	@RequestMapping("TaskUpLoad")
	public String taskUpLoad(String taskName, String courseName, String courseTeacher, MultipartFile upLoadFile,
			Model model, HttpSession session, HttpServletRequest request) {

		Integer studentId = Integer.parseInt((String) session.getAttribute("userId"));
		String url = "http://127.0.0.1:8081/Desktop/taskFile/";

		ResultCode upLoadTaskrc = new ResultCode(Common.SUCCESS, "xxx");
		try {
			upLoadTaskrc = studentService.UpLoadTask(courseTeacher, courseName, studentId, taskName, url, upLoadFile);
		} catch (Exception e) {
			if (e.getCause().toString().contains("java.sql.SQLIntegrityConstraintViolationException")) {
				upLoadTaskrc.setCode(Common.CLIENTFAILED);
				upLoadTaskrc.setMsg("您已提交此作业，请删除再次提交");
			} else {
				e.printStackTrace();
				upLoadTaskrc.setCode(Common.SERVERFAILED);
				upLoadTaskrc.setMsg("文件上传错误");
			}
		}
		System.out.println(upLoadTaskrc.getMsg());
		model.addAttribute("error", upLoadTaskrc.getMsg());
		return "admin/TaskUpLoad.html";

	}
}
