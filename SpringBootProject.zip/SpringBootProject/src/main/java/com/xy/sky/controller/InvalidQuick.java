package com.xy.sky.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InvalidQuick {

	@RequestMapping(value = "invalidQuick")
	public void invalidQuick(HttpSession session) {
		session.removeAttribute("userId");
		session.removeAttribute("user");

	}

}
