package com.xy.sky.bean;

public class Task {
	private Integer studentId;
	private Integer courseId;
	private String taskName;
	private String taskFileUrl;
	private Course course;
	private Student student;

	public Task() {
		// TODO Auto-generated constructor stub
	}

	public Task(Integer studentId, Integer courseId, String taskName, String taskFileUrl) {
		this.studentId = studentId;
		this.courseId = courseId;
		this.taskName = taskName;
		this.taskFileUrl = taskFileUrl;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskFileUrl() {
		return taskFileUrl;
	}

	public void setTaskFileUrl(String taskFileUrl) {
		this.taskFileUrl = taskFileUrl;
	}

}
