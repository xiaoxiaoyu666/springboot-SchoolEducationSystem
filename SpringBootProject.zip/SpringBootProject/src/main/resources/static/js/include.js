$(function () {
    $.get("quickLogin.html",function (data) {
        $("#login").html(data);
    });
});