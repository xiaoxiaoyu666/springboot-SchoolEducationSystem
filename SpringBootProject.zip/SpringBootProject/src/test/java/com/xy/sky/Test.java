package com.xy.sky;

import javax.servlet.http.HttpSession;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xy.sky.bean.ResultCode;
import com.xy.sky.bean.User;
import com.xy.sky.common.Common;
import com.xy.sky.mapper.CourseMapper;
import com.xy.sky.mapper.TaskScoreMapper;
import com.xy.sky.service.StudentServiceInter;

@SpringBootTest
@RunWith(SpringRunner.class)
@Controller
public class Test {

	@Autowired
	private TaskScoreMapper taskMapper;
	@Autowired
	private CourseMapper courseMapper;
	@Autowired
	private StudentServiceInter studentService;

//	@org.junit.Test
//	public void test() throws JsonProcessingException {
//		Integer[] arr = { 1, 2 };
//		List<Integer> list = Arrays.asList(arr);
//
////		List<TaskScore> querryTaskByStudentId = taskMapper.getTaskScore();
////		System.out.println(new ObjectMapper().writeValueAsString(querryTaskByStudentId));
//
////		String boundary = "---------7d4a6d158c9";
////
////		String fileName = "nb.txt";
////
////		StringBuffer s = new StringBuffer("------WebKitFormBoundary53K2CxlyXhxePZGv\r\n"
////				+ "Content-Disposition: form-data; name=\"taskName\"\r\n" + "\r\n" + "算法\r\n"
////				+ "------WebKitFormBoundary53K2CxlyXhxePZGv\r\n"
////				+ "Content-Disposition: form-data; name=\"courseName\"\r\n" + "\r\n" + "算法\r\n"
////				+ "------WebKitFormBoundary53K2CxlyXhxePZGv\r\n"
////				+ "Content-Disposition: form-data; name=\"courseTeacher\"\r\n" + "\r\n" + "张三丰\r\n"
////				+ "------WebKitFormBoundary53K2CxlyXhxePZGv\r\n"
////				+ "Content-Disposition: form-data; name=\"upLoadFile\"; filename=\"nginx操作.txt\"\r\n"
////				+ "Content-Type: text/plain\r\n" + "\r\n" + "关闭nginx\r\n" + "taskkill /f /t /im nginx.exe\r\n" + "\r\n"
////				+ "出现pid非法的解决方案\r\n" + "nginx -c conf/nginx.conf\r\n" + "------WebKitFormBoundary53K2CxlyXhxePZGv--");
////
////		int indexOf = s.indexOf("------WebKitFormBoundary53K2CxlyXhxePZGv\r\nContent");
////		int lastIndexOf = s.lastIndexOf("------WebKitFormBoundary53K2CxlyXhxePZGv\r\nContent");
////		String s1 = s.toString();
////		String[] split = s1.split("\r\n");
////		String[] split2 = s1.split(split[0]);
////		String[] split3 = split2[0].split("\r\n");
////		String substring = s1.substring(s1.lastIndexOf(split[0] + "\r\nContent-Disposition"));
////		String substring2 = substring.substring(substring.indexOf("filename") + 10,
////				substring.indexOf("Content-Type") - 3);
////		String[] split4 = substring.split("\r\n");
////		System.out.println(indexOf + "\r\n" + lastIndexOf + "\r\n" + split4[0].substring(2) + "====" + "\r\n" + s);
//
//		ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(2);
//		newFixedThreadPool.execute(new Runnable() {
//
//			@Override
//			public void run() {
//				System.out.println(Thread.currentThread());
//				System.out.println(LocalTime.now());
//				System.out.println(1);
//
//			}
//		});
//		newFixedThreadPool.execute(new Runnable() {
//
//			@Override
//			public void run() {
//				System.out.println(Thread.currentThread());
//				System.out.println(LocalTime.now());
//				System.out.println(2);
//
//			}
//		});
//
////		try {
////			URL url = new URL("http://127.0.0.1:8081/Desktop/taskFile/x.txt");
////			HttpURLConnection openConnection = (HttpURLConnection) url.openConnection();
////			openConnection.setRequestMethod("DELETE");
////			openConnection.setRequestProperty("User-Agent",
////					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36");
////			openConnection.connect();
////			System.out.println(openConnection.getResponseCode());
////		} catch (MalformedURLException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		} catch (IOException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
//	}

//	@org.junit.Test
//	public void test2() {
//		int row = courseMapper.addStudentNumToCourse(1);
//		try {
//			throw new Exception();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(row);
//	}

//	@org.junit.Test
//	public void test3() {
//		MultipartFile upLoadFile = null;
//		ResultCode upLoadTask = null;
//		try {
//			upLoadTask = studentService.UpLoadTask("张一丰", "高数", 1, "xx", "xxx", upLoadFile);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(upLoadTask);
//	}

	@org.junit.Test
	@RequestMapping("test")
	public void test4(Integer courseId, String courseTimeColumn, HttpSession session) throws Exception {
		User user = (User) session.getAttribute("user");
		Integer studentId = user.getId();
		ResultCode rc0 = studentService.JudgeCourseInCurriculum(courseTimeColumn, studentId);
		if (rc0.getCode() == Common.SUCCESS) {
			studentService.addStudentToCourse(courseId, studentId);
			studentService.updateCurriculum(courseTimeColumn, courseId, studentId);
		}
	}
}
